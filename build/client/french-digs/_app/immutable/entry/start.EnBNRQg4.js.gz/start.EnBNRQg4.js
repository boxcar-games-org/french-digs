import{l as o,a as r}from"../chunks/a76BV85z.js";export{o as load_css,r as start};
