import{l as o,a as r}from"../chunks/1j22MQ-Q.js";export{o as load_css,r as start};
